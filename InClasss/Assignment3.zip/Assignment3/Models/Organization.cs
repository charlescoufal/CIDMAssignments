ng System;
namespace Assignment3
{
    public class Organization
    {
        public int OrgID {get; set;}
        public string Name{get; set;}
        public string Business {get; set;}
        public string Phone {get; set;}
        public string Email {get; set;}
    }
}