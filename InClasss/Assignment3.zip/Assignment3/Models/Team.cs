using System;
namespace Assignment3
{
    public class Team
    {
        public int TeamID {get;set;}
        public int StudentID {get;set;}
        public int ProjectID {get; set;}
        public string TeamName {get; set;}
        
    }
}