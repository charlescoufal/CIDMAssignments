using System;
namespace Assignment3
{
    public class Advisor
    {
        public int AdvisorID {get; set;}
        public string FirstName {get; set;}
        public string LastName {get; set;}
        public string PhoneNumber {get; set;}
        public string Email {get; set;}

    }
}