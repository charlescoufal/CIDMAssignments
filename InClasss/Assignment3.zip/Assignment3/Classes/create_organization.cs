using System;

namespace Assignment3
{
    class Organization
    {
        static void Main(string[] args)
        {
            using(var db = new AppDbContext())
            {
                Organization s = new Organization()
                {
                    Name = " ",
                    Business = " ",
                    PhoneNumber = " ",
                    Email = " ",
                    

                };
                db.Organization.Add(s);

                db.SaveChanges();
            }
        }
    }
}