using System;

namespace Bufftecks.Models
{
    public class Team
    {
        public int teamID {get; set;}
        
        public string teamName {get; set;}
        
        public Project projectID {get;set;}

        public Student studentID {get; set;} 
        
       
    }
}
