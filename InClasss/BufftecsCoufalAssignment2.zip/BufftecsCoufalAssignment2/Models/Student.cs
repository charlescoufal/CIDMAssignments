using System;

namespace Bufftecks.Models
{
    public class Student
    {
        public int studentID {get; set;}
        
        public char student_fname{get; set;}
        
        public char student_lname{get; set;}
        
        public int student_phone{get; set;}
        
        public string student_email{get; set;}
        
        public string student_position{get; set;}
       
    }
}
