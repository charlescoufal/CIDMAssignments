using System;

namespace Bufftecks.Models
{
    public class Client
    {
        
        public Project projectID {get; set;} 
        
        public int clientID {get; set;}
        
        public char client_Fname{get; set;}
        
        public char client_Lname{get; set;}
        
        public int client_phone{get; set;}
        
        public string client_email{get; set;}
        
        public string client_0rganization{get; set;}
       
    }
}
