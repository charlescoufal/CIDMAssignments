using System;

namespace Assignment1
{
    public class Grad
    {
        //PK
        public long StudID{ get; set; }
      
        public string StudName { get; set; }
        
        public date DateOfBirth { get; set; }        
       
        public string Major { get; set; }
        
        public float GPA {get; set; }
       
        public string PreviousDegree { get; set; }

        public string PreviousUniversity { get; set; }
       
        public string UndergradMajor {get; set;} 

        public float UndergradGPA { get; set; }

        

    }

}